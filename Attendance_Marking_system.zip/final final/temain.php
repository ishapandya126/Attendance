<?php
include('conn.php');
?>

<html>
<head><link rel="stylesheet" type="text/css" href="wp.css">
<head>
<center>
<br><br><br><br>
<table class="td">

<tr>
<td>
<a href="def.php"><input type="submit" value="View Defaulters"  name="def"></a>
</td>
</tr>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr>
<td>
<a href="teach2.php"><input type="submit" value="Update Attendance"  name="update"></a>
</td>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr>
<td>
<input type="submit" value="Clear Database" name="truncate">
</td>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr>
<td>
<a href="finalall.php"><input type="submit" value="View full Class Attendance"  name="all"></a>
</td>
</tr>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr>
<td>
<a href="teacherValidate.php"><input type="submit" value="Sign out"  name="out"></a>
</td>
</tr>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
</table>
</center>
<?php
	
if(isset($_POST['truncate']))
{
	$sql= "truncate beit";
	$sql2="truncate seit";
	$sql3="truncate teit";
	$sql4="truncate student";
	$sql5="update subjects set conductedlec=0 where conductedlec>0";
	$result = mysqli_query($conn,$sql);
	$result2 = mysqli_query($conn,$sql3);
	$result3 = mysqli_query($conn,$sql2);
	$result4 = mysqli_query($conn,$sql4);
	$result5 = mysqli_query($conn,$sql5);
	echo"<script>alert(' Database cleared!');</script>";

}


?>




</html>