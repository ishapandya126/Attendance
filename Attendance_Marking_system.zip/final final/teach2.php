<?php
include('conn.php');
?>

<html><div id="texts">
<title>Update Attendance</title>
<head>
<link rel="stylesheet" type="text/css" href="wp.css">
</head>
<form method="post" action="teach2.php">
<br><br>
Select Class: <select name="class">
<option value=""></option>
<option value="seit">SE-IT</option>
<option value="teit">TE-IT</option>
<option value="beit">BE-IT</option>
</select><br><br><br>

<a href="temain.php"><input type="button" value="Go back" name="back"></a>
<input type="submit" name="submitclass" value="Select Semester">
<?php

if(isset($_POST['submitclass']))
{
$class=$_POST['class'];
if($class=="seit")
{
echo "<br><br><select name='semse'><option value='3'>sem 3</option><option value='4'>sem 4</option></select><br><br><input type='submit' name='submitsemse' value='Select SEIT Subject'>"; 
}
if($class=="teit")
{
echo "<br><br><select name='semte'><option value='5'>sem 5</option><option value='6'>sem 6</option></select><br><br><input type='submit' name='submitsemte' value='Select TEIT Subject'>"; 
}
if($class=="beit")
{
echo "<br><br><select name='sembe'><option value='7'>sem 7</option><option value='8'>sem 8</option></select><br><br><input type='submit' name='submitsembe' value='Select BEIT Subject'>"; 
}
if($class=="")
{
echo "Please select a class"; 
}
}
if(isset($_POST['submitsemse']))
{
	$sem=$_POST['semse'];
	$sql5="update checkss set sem='$sem',class='seit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="3")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>ADC</option><option value='sub2'>PADC</option><option value='sub3'>DSA</option><option value='sub4'>OOPM</option><option value='sub5'>DBMS</option><option value='sub6'>MATHS-3</option></select><BR><BR>
		<input type='submit' name='vclass' value='Mark Attendance'>";
		
	}
	if($sem=="4")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>AT</option><option value='sub2'>ITC</option><option value='sub3'>COA</option><option value='sub4'>WP</option><option value='sub5'>CN</option><option value='sub6'>MATHS-4</option></select><BR><BR>
		<input type='submit' name='vclass' value='Mark Attendance'>";
		
	}
	
}
if(isset($_POST['submitsemte']))
{	
	$sem=$_POST['semte'];
	$sql5="update checkss set sem='$sem',class='teit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="5")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>OS</option><option value='sub2'>MES</option><option value='sub3'>OST</option><option value='sub4'>CGVR</option><option value='sub5'>ADBMS</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	if($sem=="6")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>SE</option><option value='sub2'>DS</option><option value='sub3'>DMBI</option><option value='sub4'>SWS</option><option value='sub5'>AIT</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	
}
if(isset($_POST['submitsembe']))
{	
	$sem=$_POST['sembe'];
	$sql5="update checkss set sem='$sem',class='beit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="7")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>WT</option><option value='sub2'>IS</option><option value='sub3'>SPM</option><option value='sub4'>CC</option><option value='sub5'>ELECTIVE-1</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	if($sem=="8")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>SNMR</option><option value='sub2'>BDA</option><option value='sub3'>CSM</option><option value='sub4'>ELECTIVE-2</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	
}
if (isset($_POST['vclass']))
	{
	$sub=$_POST['semsub'];

$sql3="update checkss set sub='$sub' where no='1'";
$result = $conn->query($sql3);
$sql4="Select class from checkss where no='1'";
		$result = mysqli_query($conn,$sql4);
		$row = mysqli_fetch_assoc($result);
		$class = $row["class"];
$sql = "SELECT roll_no, name FROM $class ORDER BY roll_no";

if($result = mysqli_query($conn, $sql))
{
    if(mysqli_num_rows($result) > 0)
	{	echo "<center><br><br>";
        echo "<table border='2' cellpadding='2'>";
        echo "<tr height=50><td>Roll.no</td><td>Name</td><td></td></tr>";
        while($row = mysqli_fetch_array($result)){
			$rollno=$row['roll_no'];
            echo "<tr height=50>";
                echo "<td><h4>" . $row['roll_no'] . "</td>";
                echo "<td width=300><h3>" . $row['name'] . "</td>";
                echo "<td><input type='checkbox' name='it[]' value='$rollno'> </td>";
               
            echo "</tr>";
        }
        echo "</table>";
        // Close result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. ";
}

echo "<br><br><br><input type='submit' name='submitatt' value='Submit Attendance'><br><br>";
}
	
		
if(isset($_POST['submitatt']))
{

$att = $_POST['it'];
  if(empty($att)) 
  {
    echo("You didn't select any student.");
  } 
  else
  {
    $N = count($att);
		$sql4="Select sub,sem,class from checkss where no='1'";
		$result = mysqli_query($conn,$sql4);
		$row = mysqli_fetch_assoc($result);
		$sub = $row["sub"];
		$sem= $row["sem"];
		$class=$row["class"];
		$sqlcon="update subjects set conductedlec=conductedlec+1 where subjects='$sub' and class='$class' and sem='$sem'";
		$resultco = mysqli_query($conn,$sqlcon);
    for($i=0; $i<$N; $i++)
    {
    $roll_no=$att[$i];
	$sql = "update student set $sub=$sub+1 where roll_no='$roll_no' and class='$class' and sem='$sem'";
	$result = $conn->query($sql);
	}
	if($result)
	{
		 echo"<script>alert('Attendance marked for class $class!');</script>";
	}
  } 
}
	

?>
</div>
</form>
</html>
