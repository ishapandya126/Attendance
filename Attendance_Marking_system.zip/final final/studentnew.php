<?php
include('conn.php');
session_start();
?>
<html>
<title>View Attendance</title>
<head>
<link rel="stylesheet" type="text/css" href="wp.css"></head>
<body><div id="texts">
<center>
<form action="studentnew.php" method="post">
<table class="tb">
<tr>
<td>Username:</td>
<td><input type="text" name="user" required></td>

<td>
<select name="sem">
<option value="3">SEM-3</option>
<option value="4">SEM-4</option>
<option value="5">SEM-5</option>
<option value="6">SEM-6</option>
<option value="7">SEM-7</option>
<option value="8">SEM-8</option>
</select><td></tr>
</table><br>
<input type="submit" name="submit" value="View My attendance">
</form>
</center>


<?php
if(isset($_POST['submit']))
{
	$username=$_POST['user'];
	$sem=$_POST['sem'];
	$sql="select username from student where username='$username'and sem=$sem";
	$results = mysqli_query($conn,$sql);
	$s = mysqli_fetch_assoc($results);
	$username1= $s["username"];
	
	if($username1==$username)
	{
		$sqla="select * from student where username='$username' and sem=$sem";
		$resulta = mysqli_query($conn,$sqla);
		$row = mysqli_fetch_assoc($resulta);
		$class=$row["class"];
		$roll_no=$row["roll_no"];
		$sql2="select sub1,sub2,sub3,sub4,sub5,sub6 from student where username='$username'";
		$result2=$conn->query($sql2);
		$row= mysqli_fetch_assoc($result2);
		$sql3= "select subname from subjects where class='$class' and sem='$sem'";
		$sql4= "select conductedlec from subjects where class='$class' and sem='$sem'";
		$sql5= "select name from $class where roll_no='$roll_no'";
		$rname = mysqli_query($conn,$sql5);
		$r = mysqli_fetch_assoc($rname);
		$name= $r["name"];
		echo "<center><strong><h3>Welcome $name!</h3></strong>";
		echo "<center><br><br><table border=2><tr height=50>";
		
		if($result3 = mysqli_query($conn, $sql3))
		{
			if(mysqli_num_rows($result3) > 0)
			{
			while($rows = mysqli_fetch_array($result3))
            echo "<td width=70>" . $rows['subname'] . "</td>";
            }
			echo "</tr>";
			mysqli_free_result($result3);
		} 
		else
		{
        echo "No records matching your query were found.";
		}
 
		echo "<tr>";
		
		echo "<td>".$row["sub1"]."</td><td>".$row["sub2"]."</td><td>".$row["sub3"]."</td><td>".$row["sub4"]."</td><td>".$row["sub5"]."</td><td>".$row["sub6"]."</td>";

		echo "</tr>";

		echo "<tr>";

		if($result4 = mysqli_query($conn, $sql4))
		{ 
			if(mysqli_num_rows($result4) > 0)
			{
			$conl=array();	
			while($rows = mysqli_fetch_array($result4))
			{   
				array_push($conl,$rows['conductedlec']);
				echo "<td>" . $rows['conductedlec'] . "</td>";
			}
				
			echo "</tr>";
  
			mysqli_free_result($result4);
			}	
			else
			{
			echo "No records matching your query were found.";
			}
			
				echo "<tr height=50>";
			intval('$conl[0]');
		intval('$conl[1]');
		intval('$conl[2]');
		intval('$conl[3]');
		intval('$conl[4]');
		intval('$conl[5]');
		intval('$row["sub1"]');
		intval('$row["sub2"]');
		intval('$row["sub3"]');
		intval('$row["sub4"]');
		intval('$row["sub5"]');
		intval('$row["sub6"]');

		if($conl[0]==0)
		{
			$per1=0;
		}
		else
		{
			$per1=round(($row["sub1"]/$conl[0])*100);
		}
		if($conl[1]==0)
		{
			$per2=0;
		}
		else
		{
			$per2=round(($row["sub2"]/$conl[1])*100);
		}
		if($conl[2]==0)
		{
			$per3=0;
		}
		else
		{
			$per3=round(($row["sub3"]/$conl[2])*100);
		}
		if($conl[3]==0)
		{
			$per4=0;
		}
		else
		{
			$per4=round(($row["sub4"]/$conl[3])*100);
		}
		if($conl[4]==0)
		{
			$per5=0;
		}
		else
		{
			$per5=round(($row["sub5"]/$conl[4])*100);
		}
		if($conl[5]==0)
		{
			$per6=0;
		}
		else
		{
			$per6=round(($row["sub6"]/$conl[5])*100);
		}
		echo "<td>$per1%</td><td>$per2%</td><td>$per3%</td><td>$per4%</td><td>$per5%</td><td>$per6%</td>";
		echo "</tr>";
		echo "</table>";
		} 
		else
		{
		echo "ERROR: Could not able to execute $sql4. ";
		}
	
		//print_r($conl);
		
	}
	else
	{
	echo"<script>alert(' Username $username not registered under Semester: $sem!');</script>";
	}
}


?>
</div>
</body>
</html>

