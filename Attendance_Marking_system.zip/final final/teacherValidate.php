<?php
include('conn.php')
?>
<html>

<head><link rel="stylesheet" type="text/css" href="wp.css">
</head>
<title>Teacher Login</title>
<body>
<div id="texts">
<h1><center>Teacher Login</h1>
<form method="POST" action="">
<center>
Username :  <input type="text" name="uname" >
<br><br>
Password  :  <input type="password" name="pwd">
<br><br>
<input type="submit" value="Login" name="submit">
<br>



<?php
//ECHO "INSIDE PHP";

	if(isset($_POST['submit']))
{
	$username=$_POST['uname'];
	$password=$_POST['pwd'];

		$sql1="select username from teacher where username='$username'and password='$password'";
		$result1 = mysqli_query($conn,$sql1);
        $row = mysqli_fetch_row($result1);
        $namedb = $row[0];

        if($namedb==$username)
        {
        header("Location: temain.php"); 
    exit;		
        }
        else
        {
            echo "<script>alert('Incorrect password or username!');</script>";
        }

}


?>
</div>
</form>
</body>
</html>







