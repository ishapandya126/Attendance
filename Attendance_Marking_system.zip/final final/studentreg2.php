<?php
include('conn.php')
?>

<html>
<title>Student Register</title>
<head>
<link rel="stylesheet" type="text/css" href="wp.css">
</head>
<h1 ><center>Student Registration</center></h1>
</head>
<body background="p.jpg">
<form action="studentreg2.php" method="post">
<center>
<div id="texts">
<table class="tb">
<tr>
<td>Name:<font color="red"> *</font></td>
<td><input type="text" name="name" required></td>
</tr>
<tr>
<td>Username:<font color="red"> *</font></td>
<td><input type="text" name="username" required></td>
</tr>
<tr>
<td>Roll No:<font color="red"> *</font></td>
<td><input type="text" name="rno" required></td>
</tr>
<tr>
<td>Email:<font color="red"> *</font></td>
<td><input type="text" name="email" required></td>
</tr>
<tr>
<td>Class:<font color="red"> *</font></td>
<td><select name="class">
  <option value="seit">SEIT</option>
  <option value="teit">TEIT</option>
  <option value="beit">BEIT</option>  
  </select></td>
</tr>
<tr>
<td>Contact:<font color="red"> *</font></td>
<td><input type="text" name="contact" required></td>
<tr>
</table>
<input type="submit" value="Submit" name="submit">
</center>
</div>

<?php

if(isset($_POST['submit']))
{    
    $name = $_POST['name'];
    $rno = $_POST['rno'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $class = $_POST['class'];
	$username = $_POST['username'];
	$sqll="select username from student where username='$username'";
	$resultt = mysqli_query($conn,$sqll);
	$s = mysqli_fetch_array($resultt);
	if(mysqli_num_rows($resultt)==1)
	{
	echo"<script>alert(' Username already taken!');</script>";
	}
	else
	{
    $sql = "INSERT INTO $class VALUES ('$rno' , '$name' , '$email' , '$contact')";
    $result = mysqli_query($conn , $sql);
    
    if($class=="seit")
    {

		$sql2 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '3', 0,0,0,0,0,0)";
        $result1 = mysqli_query($conn,$sql2);
 
		$sql3 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '4', 0,0,0,0,0,0)";
        $result2 = mysqli_query($conn,$sql3);
		
		if($result1 && $result2)
			echo "<script>alert('Student Registered');</script>";
		else echo "<script>alert('Registration Failed');</script>";
	}
	    if($class=="teit")
    {

		$sql2 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '5', 0,0,0,0,0,0)";
        $result1 = mysqli_query($conn,$sql2);
 
		$sql3 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '6', 0,0,0,0,0,0)";
        $result2 = mysqli_query($conn,$sql3);
		
		if($result1 && $result2)
			echo "<script>alert('Student Registered');</script>";
		else echo "<script>alert('Registration Failed');</script>";
	}
	    if($class=="beit")
    {

		$sql2 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '7', 0,0,0,0,0,0)";
        $result1 = mysqli_query($conn,$sql2);
 
		$sql3 = "INSERT INTO student VALUES ('$rno' , '$username' , '$class' , '8', 0,0,0,0,0,0)";
        $result2 = mysqli_query($conn,$sql3);
		
		if($result1 && $result2)
			echo "<script>alert('Student Registered!');</script>";
		
		else echo "<script>alert('Registration Failed.');</script>";
	}
	}
	
}

?>
</form>
</body>
</html>
