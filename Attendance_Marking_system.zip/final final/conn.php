<?php
$user_name = "root";
$password = "";
$database = "attendance";
$server = "127.0.0.1";

$conn = new mysqli($server, $user_name, $password, $database);
?>