<?php
include('conn.php')
?>
<html>
<title>Display Attendance</title>
<head>
<link rel="stylesheet" type="text/css" href="wp.css">
</head>
<div id="texts">
<form action="finalall.php" method="post">
Select Class: <select name="class">
<option value=""></option>
<option value="seit">SE-IT</option>
<option value="teit">TE-IT</option>
<option value="beit">BE-IT</option>
</select>

<input type="submit" name="submit" value="View Attendance">
<br><br>
<a href="temain.php"><input type="button" value="Go back" name="back"></a>

<?php

if(isset($_POST['submit']))
{
$class=$_POST['class'];
if($class=="seit")
{
echo "<br><br><select name='semse'><option value='3'>sem 3</option><option value='3'>sem 4</option></select><br><input type='submit' name='submitsemse' value='Select SEIT Subject'>"; 
}
if($class=="teit")
{
echo "<br><br><select name='semte'><option value='5'>sem 5</option><option value='6'>sem 6</option></select><br><input type='submit' name='submitsemte' value='Select TEIT Subject'>"; 
}
if($class=="beit")
{
echo "<br><br><select name='sembe'><option value='7'>sem 7</option><option value='8'>sem 8</option></select><br><input type='submit' name='submitsembe' value='Select BEIT Subject'>"; 
}
if($class=="")
{
echo "Please select a class"; 
}
}
if(isset($_POST['submitsemse']))
{
	$sem=$_POST['semse'];
	$sql5="update checkss set sem='$sem',class='seit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="3")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>ADC</option><option value='sub2'>PADC</option><option value='sub3'>DSA</option><option value='sub4'>OOPM</option><option value='sub5'>DBMS</option><option value='sub6'>MATHS-3</option></select><BR><BR>
		<input type='submit' name='vclass' value='Mark Attendance'>";
		
	}
	if($sem=="4")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>AT</option><option value='sub2'>ITC</option><option value='sub3'>COA</option><option value='sub4'>WP</option><option value='sub5'>CN</option><option value='sub6'>MATHS-4</option></select><BR><BR>
		<input type='submit' name='vclass' value='Mark Attendance'>";
		
	}
	
}
if(isset($_POST['submitsemte']))
{	
	$sem=$_POST['semte'];
	$sql5="update checkss set sem='$sem',class='teit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="5")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>OS</option><option value='sub2'>MES</option><option value='sub3'>OST</option><option value='sub4'>CGVR</option><option value='sub5'>ADBMS</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	if($sem=="6")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>SE</option><option value='sub2'>DS</option><option value='sub3'>DMBI</option><option value='sub4'>SWS</option><option value='sub5'>AIT</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	
}
if(isset($_POST['submitsembe']))
{	
	$sem=$_POST['sembe'];
	$sql5="update checkss set sem='$sem',class='beit' where no='1'";
	$result = $conn->query($sql5);
	if($sem=="7")
	{	
		echo "<br><br><select name='semsub'><option value='sub1'>WT</option><option value='sub2'>IS</option><option value='sub3'>SPM</option><option value='sub4'>CC</option><option value='sub5'>ELECTIVE-1</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	if($sem=="8")
	{
		echo "<br><br><select name='semsub'><option value='sub1'>SNMR</option><option value='sub2'>BDA</option><option value='sub3'>CSM</option><option value='sub4'>ELECTIVE-2</option></select><BR><BR><input type='submit' name='vclass' value='Mark Attendance'>";
	}
	
}
if (isset($_POST['vclass']))
	{
	$sub=$_POST['semsub'];

$sql3="update checkss set sub='$sub' where no='1'";
$result = $conn->query($sql3);
$sql4="Select sem,class from checkss where no='1'";
		$result = mysqli_query($conn,$sql4);
		$row = mysqli_fetch_assoc($result);
		$class = $row["class"];
		$sem=$row["sem"];
		$sql = "SELECT roll_no, name FROM $class ORDER BY roll_no";
		$sql2= " Select $sub from student where class='$class' and sem='$sem' ORDER BY roll_no";
		$sql4= "select conductedlec from subjects where class='$class' and sem='$sem'and subjects='$sub'";
		$result = mysqli_query($conn,$sql4);
		$row1 = mysqli_fetch_assoc($result);
		$conl = $row1["conductedlec"];

//echo "conducted".$conl;
echo "<div id='tab'>";
if($result = mysqli_query($conn, $sql))
{
    if(mysqli_num_rows($result) > 0)
	{ 
       
         $defnam= array();
		 $defrn=array();
        while($row = mysqli_fetch_array($result))
		{
			$rollno=$row['roll_no'];
        array_push($defnam,$row['name']);
		array_push($defrn,$row['roll_no']);
        }
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. ";
}
if($result1=mysqli_query($conn,$sql2))
{
if(mysqli_num_rows($result1) > 0)
	
	{
		$defper=array();

          while($row2 = mysqli_fetch_array($result1))
		  {	
			$ap= intval($row2["$sub"]);
           if($conl==0)
			{
			$per=0;	
			}
			else $per= intval(($ap/$conl)*100);
			array_push($defper,$per);
        }
		$n=count($defnam);
		$sqls="select subname from subjects where subjects='$sub' and class='$class' and sem='$sem'";
		$result4 = mysqli_query($conn,$sqls);
			$r = mysqli_fetch_assoc($result4);
			$subname = $r["subname"];
		echo "<center><br><br>Attendance in: ".$subname."<br><br><center><table border=2><tr height=50><th>Roll. no</th><th>Student Name</th><th>Attendance %</th></tr>";

	for($i=0;$i<$n;$i++)
	{
		
			
			echo "<center><tr height=50>";
			echo "<td>".$defrn[$i]."</td>";
			echo "<td width=300>".$defnam[$i]."</td>";
			echo "<td>".$defper[$i]."</td>";
			echo "</tr>";
			
		
	}	
	echo "<center></table>";
    } 
	else{
        echo "<center>No records matching your query were found.";
    }
} else{
    echo "<center>ERROR: Could not able to execute $sql. ";
}	

	}
	
	
		
?>
</div>
</form>
</html>